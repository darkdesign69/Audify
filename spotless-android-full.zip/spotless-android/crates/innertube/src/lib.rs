//! Pure-Rust InnerTube transport + client identities + models + endpoints + rustypipe fallback.
//!
//! The boundary rule (context/11): this crate knows nothing about Tauri, webviews, mpv, or the
//! OS. It is unit-testable against JSON fixtures with no network. Cipher/PoToken/WEB_REMIX
//! streaming are Phase 2 and deliberately absent here.

pub mod blocklist;
pub mod clients;
pub mod credits; // lane magic-d1
pub mod comments_session;
pub mod ctoken;
pub mod endpoints;
// ── stream: polish ──
pub mod explore;
// ── end stream: polish ──
pub mod models;
// ── stream: podcasts ──
pub mod podcasts;
// ── end stream: podcasts ──
// ── stream: reliability ──
pub mod reliability;
// ── end stream: reliability ──
pub mod rustypipe_fallback;
// ── stream: search2 ──
pub mod search;
// ── end stream: search2 ──
#[cfg(test)]
mod test_server;
pub mod transport;

pub use blocklist::BlockList;
pub use clients::{
    Clients, YouTubeClient, LYRICS_TIMED_CLIENT, MAIN_CLIENT, METADATA_CLIENT,
    STREAM_FALLBACK_ORDER, UPLOAD_FALLBACK_ORDER,
};
pub use comments_session::{ActionError, CommentsSession, Provenance};
pub use models::browse::{
    AlbumPage, ArtistCarousel, ArtistPage, BrowseItem, HistoryGroup, HomePage, LiveVideo, Mood,
    MoodSection, PlaylistContinuation, PlaylistPage, PlaylistSort, PlaylistSuggestions,
    QuerySuggestion, SearchResults, SearchSuggestions, Section, SortMenu,
};
pub use models::comment_write::{CommentWrite, WriteCommand};
pub use models::comments::{
    parse_written_comment, Comment, CommentAction, CommentReplies, CommentSortKey, CommentThread,
    CommentsPage, CommentsState, VoteState,
};
pub use models::context::Locale;
pub use models::lyrics::{PlainLyrics, TimedLyricLine};
pub use models::metadata::{
    AccountIdentity, AccountInfo, NextResult, Rating, SearchResult, Segment, SongItem,
};
pub use models::player::{
    find_format, find_video_format, pick_hls_variant, AudioQuality, Format, Live, PlaybackTracking,
    PlayerResponse, StreamingData,
};
pub use search::SearchFilter; // stream: search2
pub use rustypipe_fallback::{FallbackError, StreamCandidate};
pub use transport::{
    cookie_sapisid, generate_cpn, without_healing, Error, Healing, InnerTube, Session,
};
// ── stream: reliability ──
pub use reliability::{background, current_priority, speculative, Limits, Priority, StatsSnapshot};
pub use transport::{is_version_like, WebConfig};
// ── end stream: reliability ──
